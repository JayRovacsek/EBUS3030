﻿namespace ParseDataCSharp.Classes
{
    public class Customer : Person
    {
    }
}