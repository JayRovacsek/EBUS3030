﻿namespace ParseDataCSharp.Classes
{
    public class Staff : Person
    {
        public int OfficeId { get; set; }
    }
}